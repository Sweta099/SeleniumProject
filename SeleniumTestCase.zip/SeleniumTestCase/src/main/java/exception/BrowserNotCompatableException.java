package exception;

public class BrowserNotCompatableException extends Exception {
	
	public BrowserNotCompatableException(String string) {
		super(string);
	}


}
